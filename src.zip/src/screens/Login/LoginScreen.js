// src/screens/Login/LoginScreen.js
import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { useApp } from "../../store";
import Config from "react-native-config";
import reqHelper from "../../features/helpers/reqHelper";

const COLORS = {
  bg: "#0f172a",
  card: "#111827",
  primary: "#2563eb",
  border: "#1f2937",
  text: "#e5e7eb",
  textSoft: "#9ca3af",
  danger: "#ef4444",
};

export default function LoginScreen() {
  const navigation = useNavigation();
  const { setCurrentUserFromBackend } = useApp();

  const [correo, setCorreo] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const irAlMain = () => {
    navigation.replace("Main");
  };

  const handleLogin = async () => {
    setError("");

    const emailTrim = (correo || "").trim();
    const passTrim = (password || "").trim();

    if (!emailTrim || !passTrim) {
      setError("Debes ingresar correo y contraseña.");
      return;
    }

    try {
      setLoading(true);

      // Ajusta la ruta según tu backend real
      const url = `${Config.API_URL}/login.php`;

      const res = await reqHelper(url, "post", {
        correo: emailTrim,
        password: passTrim,
      });

      if (res.error) {
        const msg =
          res.body ||
          res.message ||
          "No se pudo iniciar sesión. Revisa tus credenciales.";
        setError(msg);
        return;
      }

      const payload = res.data || res.body || res;
      const userBackend =
        payload.user || payload.data || payload.usuario || payload;

      if (!userBackend) {
        setError("Respuesta de login inválida desde el servidor.");
        return;
      }

      setCurrentUserFromBackend(userBackend);
      irAlMain();
    } catch (e) {
      console.log("[LoginScreen] error login", e);
      setError(
        e.message || "Ocurrió un error inesperado al iniciar sesión."
      );
    } finally {
      setLoading(false);
    }
  };

  const goToRegister = () => {
    navigation.navigate("Register");
  };

  return (
    <View style={styles.screen}>
      <View style={styles.card}>
        <Text style={styles.title}>Ingreso</Text>
        <Text style={styles.subtitle}>
          Accede con tu usuario de cubicaje.
        </Text>

        <Text style={styles.label}>Correo</Text>
        <TextInput
          value={correo}
          onChangeText={setCorreo}
          autoCapitalize="none"
          keyboardType="email-address"
          placeholder="correo@empresa.cl"
          placeholderTextColor={COLORS.textSoft}
          style={styles.input}
        />

        <Text style={styles.label}>Contraseña</Text>
        <TextInput
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          placeholder="********"
          placeholderTextColor={COLORS.textSoft}
          style={styles.input}
        />

        {error ? <Text style={styles.error}>{error}</Text> : null}

        <TouchableOpacity
          style={[styles.btn, loading && styles.btnDisabled]}
          onPress={handleLogin}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.btnText}>Ingresar</Text>
          )}
        </TouchableOpacity>

        <View style={styles.footerRow}>
          <Text style={styles.footerText}>
            ¿No tienes cuenta?
          </Text>
          <TouchableOpacity onPress={goToRegister}>
            <Text style={styles.footerLink}> Regístrate aquí</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: COLORS.bg,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 16,
  },
  card: {
    width: "100%",
    maxWidth: 380,
    backgroundColor: COLORS.card,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  title: {
    fontSize: 22,
    fontWeight: "800",
    color: COLORS.text,
    marginBottom: 4,
    textAlign: "center",
  },
  subtitle: {
    fontSize: 12,
    color: COLORS.textSoft,
    textAlign: "center",
    marginBottom: 16,
  },
  label: {
    color: COLORS.textSoft,
    fontSize: 12,
    marginTop: 8,
    marginBottom: 4,
  },
  input: {
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: COLORS.text,
    backgroundColor: "#020617",
    fontSize: 14,
  },
  error: {
    color: COLORS.danger,
    fontSize: 11,
    marginTop: 6,
  },
  btn: {
    backgroundColor: COLORS.primary,
    borderRadius: 10,
    paddingVertical: 12,
    marginTop: 16,
    alignItems: "center",
  },
  btnDisabled: {
    opacity: 0.7,
  },
  btnText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 15,
  },
  footerRow: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 12,
  },
  footerText: {
    fontSize: 11,
    color: COLORS.textSoft,
  },
  footerLink: {
    fontSize: 11,
    color: COLORS.primary,
    fontWeight: "600",
  },
});
