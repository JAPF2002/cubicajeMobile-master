const images = {
    spaceDimension: require('./spaceDimension.png'),
    productDimension: require('./productDimension.png'),
    productInfo: require('./productInfo.png'),
    spaceDimension2: require('./spaceDimension2.png'),
    planning: require('./planning.png'),
    calculating: require('./calculating.png'),
    altura: require('./altura.png'),
    anchura: require('./anchura.png'),
    profundidad: require('./profundidad.png'),
    firstOrientation: require('./first-orientation.png'),
    secondOrientation: require('./second-orientation.png'),
    thirdOrientation: require('./third-orientation.png')
}

export default images;