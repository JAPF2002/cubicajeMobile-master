// Neutraliza configuración personalizada del CLI
module.exports = {};
